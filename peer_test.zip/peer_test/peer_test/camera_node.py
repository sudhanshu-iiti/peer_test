import rclpy  
from rclpy.node import Node  
import cv2  
from cv_bridge import CvBridge 
from sensor_msgs.msg import Image 

class CameraNode(Node):
    def __init__(self):
        super().__init__('camera')  
        self.publisher_ = self.create_publisher(Image, 'camera_image', 1)  
        self.timer = self.create_timer(0.001, self.timer_callback) 
        self.cap = cv2.VideoCapture(0)  
        self.bridge = CvBridge()         

    def timer_callback(self):
        ret, frame = self.cap.read()  
        
        if ret: 
            
            frame = cv2.resize(frame,(640,480), interpolation=cv2.INTER_NEAREST)
            msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
            self.publisher_.publish(msg) 
            if cv2.waitKey(1) & 0xFF == ord('q'): 
                rclpy.shutdown() 
        else:
            self.get_logger().error('Failed to capture image')  

def main(args=None):
    rclpy.init(args=args)  
    node = CameraNode()  
    try:
        rclpy.spin(node)  
    except KeyboardInterrupt:
        pass 
    finally:
        node.cap.release()  
        cv2.destroyAllWindows()  
        node.destroy_node() 
        rclpy.shutdown()  

if __name__ == '__main__':
    main()  

