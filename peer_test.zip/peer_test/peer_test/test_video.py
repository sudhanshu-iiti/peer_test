import rclpy
from rclpy.node import Node
import cv2
from ultralytics import YOLO


class ObjectDetectionNode(Node):
    def __init__(self):
        super().__init__('object_detection_node')
        self.model = YOLO('/home/USER/ws_cv/required_files/peer/seg.pt')
        self.video_path = '/home/USER/ws_cv/required_files/peer/videoplayback.mp4'
        self.cap = cv2.VideoCapture(self.video_path)
        if not self.cap.isOpened():
            self.get_logger().error("Could not open video file.")
            return
        self.timer = self.create_timer(0.1, self.process_frame)
        self.get_logger().info("Object Detection Node Initialized.")

    def process_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().info("End of video or error reading frame.")
            self.cap.release()
            cv2.destroyAllWindows()
            self.timer.cancel()
            return
        results = self.model(frame)
        annotated_frame = results[0].plot()
        for box in results[0].boxes:
            b = box.xywh[0].tolist()
            self.get_logger().info(f"Bounding Box: {b}")
        cv2.imshow('Video Inference', annotated_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            self.get_logger().info("Exiting...")
            self.cap.release()
            cv2.destroyAllWindows()
            self.timer.cancel()


def main(args=None):
    rclpy.init(args=args)
    node = ObjectDetectionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
