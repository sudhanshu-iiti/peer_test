import rclpy
from rclpy.node import Node
import cv2
from ultralytics import YOLO
from cv_bridge import CvBridge
from sensor_msgs.msg import Image


class ObjectDetectionSubscriber(Node):
    def __init__(self):
        super().__init__('object_detection_node')
        self.model = YOLO('/home/USER/ws_cv/required_files/peer/seg.pt')
        self.subscription = self.create_subscription(
            Image,
            'webcam_image',
            self.image_callback,
            1
        )
        self.bridge = CvBridge()
        self.get_logger().info("Object Detection Node Initialized.")

    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        results = self.model(frame)
        annotated_frame = results[0].plot()
        for box in results[0].boxes:
            b = box.xywh[0].tolist()
            self.get_logger().info(f"Bounding Box: {b}")
        cv2.imshow('Object Detection', annotated_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            self.get_logger().info("Exiting...")
            cv2.destroyAllWindows()
            rclpy.shutdown()


def main(args=None):
    rclpy.init(args=args)
    node = ObjectDetectionSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        cv2.destroyAllWindows()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
